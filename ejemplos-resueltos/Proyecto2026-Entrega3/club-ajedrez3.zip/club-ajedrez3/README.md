# Club de Ajedrez "Torre Blanca" — Entrega 3 (JDBC)

Ejemplo resuelto de la Entrega 3 del Proyecto Integrador (Programación Avanzada, 2do BT).
Es el mismo proyecto `club-ajedrez2` de la Entrega 2, con el DAO conectado a MySQL.

## Qué cambia respecto de la Entrega 2

| Archivo | Cambio |
|---|---|
| `pom.xml` | Dependencia `mysql-connector-j` |
| `src/main/resources/db.properties` | **Nuevo**: URL, usuario y contraseña de la BD |
| `src/main/java/modelo/conexion/Conexion.java` | **Nuevo**: lee `db.properties` y entrega conexiones con `obtener()` |
| `src/main/java/modelo/dao/SocioDAO.java` | Usa JDBC en vez de `ArrayList` (mismos métodos) |
| `src/main/webapp/WEB-INF/web.xml` | Lectura de formularios en UTF-8 |
| `sql/club_ajedrez.sql` | **Nuevo**: la base del club (script de la Entrega 3 de BD) y el usuario `app_club` |

El Servlet (`SocioControladorServlet`), los VO (`Persona`, `Socio`) y los JSP **no cambian**.

## Cómo ejecutarlo

1. Ejecutar `sql/club_ajedrez.sql` en MySQL Workbench (conectado como root).
2. Revisar que `db.properties` coincida con el usuario y la contraseña creados.
3. Compilar y desplegar igual que en la Entrega 2 (indicando `-Dtomcat.home=C:\apache-tomcat-10.1.57` si Tomcat está en otra ruta).
4. Abrir `http://localhost:8080/club-ajedrez3/`
5. Dar de alta un socio, dar de baja otro, reiniciar Tomcat y verificar que los cambios siguen ahí.

---
Prof. Elizabeth Izquierdo — Programación Avanzada 2026 — CC BY-SA 4.0
