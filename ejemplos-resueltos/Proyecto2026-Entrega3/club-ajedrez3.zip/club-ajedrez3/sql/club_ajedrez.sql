-- =========================================================
-- Club de Ajedrez "Torre Blanca"
-- Script de la Entrega 3 de Base de Datos + usuario de la aplicación web
-- Ejecutar en MySQL como root ANTES de desplegar la aplicación.
-- Esquema: el de la Entrega 2 (pasaje a tablas, en 3FN)
-- =========================================================

DROP DATABASE IF EXISTS club_ajedrez;
CREATE DATABASE club_ajedrez CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE club_ajedrez;

-- ---------------------------------------------------------
-- 1) Tablas sin FK (entidades fuertes)
-- ---------------------------------------------------------
CREATE TABLE Socio (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    nombre           VARCHAR(30) NOT NULL,
    apellido         VARCHAR(30) NOT NULL,
    fecha_nacimiento DATE        NOT NULL,
    categoria        VARCHAR(20) NOT NULL,
    pago_al_dia      BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE Entrenador (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    nombre       VARCHAR(30) NOT NULL,
    apellido     VARCHAR(30) NOT NULL,
    especialidad VARCHAR(40)
);

CREATE TABLE Torneo (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    fecha  DATE        NOT NULL,
    tipo   VARCHAR(20) NOT NULL,
    UNIQUE (nombre, fecha)           -- no se repite el mismo torneo el mismo día
);

CREATE TABLE Material (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    tipo     VARCHAR(30) NOT NULL,
    estado   VARCHAR(15) NOT NULL,
    cantidad INT         NOT NULL
);

-- ---------------------------------------------------------
-- 2) Relación 1:N → FK del lado N
-- ---------------------------------------------------------
CREATE TABLE ClaseAjedrez (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    nombre        VARCHAR(40) NOT NULL,
    dia           VARCHAR(10) NOT NULL,
    horario       TIME        NOT NULL,
    cupo_maximo   INT         NOT NULL,
    entrenador_id INT         NOT NULL,
    FOREIGN KEY (entrenador_id) REFERENCES Entrenador(id)
);

-- ---------------------------------------------------------
-- 3) Relaciones N:M → tablas intermedias con PK compuesta
-- ---------------------------------------------------------
CREATE TABLE Inscripcion (
    socio_id          INT  NOT NULL,
    clase_id          INT  NOT NULL,
    fecha_inscripcion DATE NOT NULL,
    PRIMARY KEY (socio_id, clase_id),
    FOREIGN KEY (socio_id) REFERENCES Socio(id),
    FOREIGN KEY (clase_id) REFERENCES ClaseAjedrez(id)
);

CREATE TABLE Participacion (
    socio_id  INT NOT NULL,
    torneo_id INT NOT NULL,
    resultado VARCHAR(20),
    PRIMARY KEY (socio_id, torneo_id),
    FOREIGN KEY (socio_id)  REFERENCES Socio(id),
    FOREIGN KEY (torneo_id) REFERENCES Torneo(id)
);

CREATE TABLE Uso (
    clase_id       INT NOT NULL,
    material_id    INT NOT NULL,
    cantidad_usada INT NOT NULL,
    PRIMARY KEY (clase_id, material_id),
    FOREIGN KEY (clase_id)    REFERENCES ClaseAjedrez(id),
    FOREIGN KEY (material_id) REFERENCES Material(id)
);

-- =========================================================
-- Datos de prueba (primero las tablas padre, después las hijas)
-- =========================================================
INSERT INTO Socio (id, nombre, apellido, fecha_nacimiento, categoria, pago_al_dia) VALUES
    (1, 'Ana',     'García',    '2010-03-15', 'Juvenil', TRUE),
    (2, 'Carlos',  'López',     '1990-07-22', 'Adulto',  FALSE),
    (3, 'Lucía',   'Fernández', '2012-11-02', 'Infantil', TRUE),
    (4, 'Martín',  'Rodríguez', '1985-01-30', 'Adulto',  TRUE),
    (5, 'Sofía',   'Pereira',   '2008-06-18', 'Juvenil', FALSE),
    (6, 'Diego',   'Silva',     '1958-09-09', 'Veterano', TRUE);

INSERT INTO Entrenador (id, nombre, apellido, especialidad) VALUES
    (1, 'Laura',  'Méndez',   'Aperturas'),
    (2, 'Jorge',  'Acosta',   'Finales'),
    (3, 'Andrea', 'Cabrera',  'Ajedrez para niños');

INSERT INTO Torneo (id, nombre, fecha, tipo) VALUES
    (1, 'Abierto de Primavera',  '2026-09-20', 'Clásico'),
    (2, 'Relámpago de Octubre',  '2026-10-11', 'Blitz'),
    (3, 'Copa Torre Blanca',     '2026-11-28', 'Rápido');

INSERT INTO Material (id, tipo, estado, cantidad) VALUES
    (1, 'Tablero',            'Bueno',   20),
    (2, 'Juego de piezas',    'Bueno',   20),
    (3, 'Reloj de ajedrez',   'Regular', 10),
    (4, 'Tablero mural',      'Bueno',    2);

INSERT INTO ClaseAjedrez (id, nombre, dia, horario, cupo_maximo, entrenador_id) VALUES
    (1, 'Iniciación',       'Lunes',     '18:00', 12, 3),
    (2, 'Aperturas',        'Miércoles', '19:00', 10, 1),
    (3, 'Finales',          'Jueves',    '19:00', 10, 2),
    (4, 'Infantil sábados', 'Sábado',    '10:00', 15, 3);

INSERT INTO Inscripcion (socio_id, clase_id, fecha_inscripcion) VALUES
    (1, 2, '2026-03-05'),
    (2, 2, '2026-03-06'),
    (2, 3, '2026-03-06'),
    (3, 4, '2026-03-10'),
    (4, 3, '2026-04-01'),
    (5, 1, '2026-04-15'),
    (5, 2, '2026-05-02'),
    (6, 3, '2026-03-20');

INSERT INTO Participacion (socio_id, torneo_id, resultado) VALUES
    (1, 1, '3.º puesto'),
    (2, 1, '5.º puesto'),
    (4, 1, '1.er puesto'),
    (4, 2, '2.º puesto'),
    (5, 2, '6.º puesto'),
    (6, 3, NULL);                     -- torneo todavía no jugado

INSERT INTO Uso (clase_id, material_id, cantidad_usada) VALUES
    (1, 1, 12),
    (1, 2, 12),
    (2, 4,  1),
    (3, 3, 10),
    (4, 1, 15);

-- =========================================================
-- Usuario de la aplicación web (lo usa db.properties)
-- =========================================================
DROP USER IF EXISTS 'app_club'@'localhost';
CREATE USER 'app_club'@'localhost' IDENTIFIED BY 'club2026';
GRANT SELECT, INSERT, DELETE ON club_ajedrez.Socio TO 'app_club'@'localhost';
