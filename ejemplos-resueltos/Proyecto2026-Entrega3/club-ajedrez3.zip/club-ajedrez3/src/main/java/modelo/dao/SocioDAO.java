package modelo.dao;

import modelo.conexion.Conexion;
import modelo.vo.Socio;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de Socio con JDBC (Entrega 3).
 * Mantiene los mismos métodos que en la Entrega 2 (agregar, getLista, eliminar),
 * por eso el Servlet y los JSP no cambian.
 * Los socios de prueba ya no se crean en el constructor: están en sql/club_ajedrez.sql.
 */
public class SocioDAO {

    // ALTA: inserta un socio. El id lo genera MySQL (AUTO_INCREMENT).
    public void agregar(Socio socio) {
        // Fase 1: definir el SQL con ?
        String sql = "INSERT INTO Socio (nombre, apellido, fecha_nacimiento, "
                   + "categoria, pago_al_dia) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexion.obtener();                 // Fase 2: conexión
             PreparedStatement ps = con.prepareStatement(sql)) {  // Fase 3: preparar

            // Fase 3: asignar los ? (en el mismo orden que en el SQL)
            ps.setString(1, socio.getNombre());
            ps.setString(2, socio.getApellido());
            // LocalDate -> DATE
            ps.setDate(3, Date.valueOf(socio.getFechaNacimiento()));
            ps.setString(4, socio.getCategoria());
            ps.setBoolean(5, socio.isPagoAlDia());

            ps.executeUpdate();          // Fase 4: ejecutar
            // Sin Fase 5: INSERT no devuelve ResultSet

        } catch (SQLException e) {
            System.err.println("Error al agregar el socio: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // LISTADO: devuelve todos los socios guardados en la base de datos.
    public List<Socio> getLista() {
        List<Socio> lista = new ArrayList<>();
        // Fase 1: definir el SQL
        String sql = "SELECT id, nombre, apellido, fecha_nacimiento, "
                   + "categoria, pago_al_dia FROM Socio";

        try (Connection con = Conexion.obtener();                 // Fase 2: conexión
             PreparedStatement ps = con.prepareStatement(sql);    // Fase 3: preparar
             ResultSet rs = ps.executeQuery()) {                  // Fase 4: ejecutar

            while (rs.next()) {                                   // Fase 5: leer el ResultSet
                Socio s = new Socio(
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        // DATE -> LocalDate
                        rs.getDate("fecha_nacimiento").toLocalDate(),
                        rs.getString("categoria"));
                s.setId(rs.getInt("id"));          // necesario para la baja
                s.setPagoAlDia(rs.getBoolean("pago_al_dia"));
                lista.add(s);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los socios: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;   // si falla, devuelve una lista vacía (nunca null)
    }

    // BAJA: elimina el socio con el id indicado.
    public void eliminar(int id) {
        // Fase 1: definir el SQL (¡sin WHERE se borraría TODA la tabla!)
        String sql = "DELETE FROM Socio WHERE id = ?";

        try (Connection con = Conexion.obtener();                 // Fase 2: conexión
             PreparedStatement ps = con.prepareStatement(sql)) {  // Fase 3: preparar

            ps.setInt(1, id);            // Fase 3: asignar el ?
            ps.executeUpdate();          // Fase 4: ejecutar

        } catch (SQLException e) {
            System.err.println("Error al dar de baja el socio: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
